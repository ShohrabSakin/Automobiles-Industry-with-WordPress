<section>
<?php dynamic_sidebar( 'Leftsidebar' );//combination of many widgets in sidebar,no code is needed for them ?>
</section>
<footer>
      <p>Copyright &copy; 2019</p>
    </footer>
    <?php wp_footer(); ?>

    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <script>
$(document).ready(function(){
  
  $("div.menu>ul").addClass("navbar-nav");
  $("div.menu>ul>li").addClass("nav-item");
  //$("<span class='caret'></span>").insertBefore("div.menu>ul>li>ul");
  $(".page_item_has_children>a").after("<span class='caret'></span>");
  $("div.menu>ul>li>ul").addClass("dropdown-menu");

  $("div.menu>ul>li>ul>li>a").addClass("dropdown-item");
  $(".page_item_has_children").addClass("nav-item dropdown");
  $(".page_item_has_children>a").addClass("dropdown-toggle");
  $(".page_item_has_children>a").attr("data-bs-toggle","dropdown");
  $(".page_item_has_children>a").attr("aria-expanded","false");
  
  $("div.menu a").addClass("nav-link");
  $("div.menu").addClass("navbar-collapse collapse");
  $("div.menu").removeClass("menu");
  //alert("got")
})

</script>
</div>
  </body>
</html>
